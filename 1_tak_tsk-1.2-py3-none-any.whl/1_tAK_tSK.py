#text-aksk
#这是测试的aksk，无风险，泄漏不会有风险。。
import os

#accessID=LTAI5tEt2c8By9hQ7p9qBKrQ
#accesskey=1NvihL4mdfL9piR9iqNTVCQWrXUEOe

class Method:
    def __init__(self,name,age):
        self.f_name = name
        self.f_age = age
        print("init success",self.f_name,self.f_age)
 
 
    def getInfo(name,age):
        print(name+"#######"+age)
 
    def my_getInfo(self):
        print(self.f_name,"##########",self.f_age)